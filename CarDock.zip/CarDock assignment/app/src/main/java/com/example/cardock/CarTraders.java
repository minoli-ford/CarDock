package com.example.cardock;

public class CarTraders {
    private String companyName;
    private String id;
    private String email;
    private int contactNo;
    private String address;

    public void signup(){

    }

    public void login(){

    }

    public void updateProfile(){

    }

    public void sellCar(){

    }

    public void viewCar(){

    }

    public void updateCar(){

    }
}
