package com.example.cardock;

public class Admin {
    private String adminName;
    private String email;

    public void login(){

    }

    public void deleteCustomer(){

    }

    public void deleteCompany(){

    }

    public void viewSoldCar(){

    }

    public void viewBroughtCar(){

    }

}
