package com.example.cardock;

public class Customer {
    private String customerName;
    private String id;
    private String email;
    private int contactNo;
    private String address;

    public void signup(){

    }

    public void login(){

    }

    public void updateProfile(){

    }

    public void buyCar(){

    }

    public void sellCar(){

    }

    public void viewCar(){

    }

    public void updateCar(){

    }
}
